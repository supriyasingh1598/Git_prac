var ksModule = angular.module('demorole1', ['ui.bootstrap']);

ksModule.controller('demorole1Controller', function($scope, $http, $uibModal) {
	
    /*
    * Declared required variables
    */
	var REST_BASE_URL = 'http://localhost:8080/identityiq/plugin/rest/';
	$scope.currentUser = PluginHelper.getCurrentUsername();
    $scope.ALL_ROLES = [];
    $scope.ORG_ROLES = [];
    $scope.BSN_ROLES = [];
    $scope.IT_ROLES = [];
    $scope.SHOW_ROLES = [];
    $scope.ATV_INDEX = -1;
    $scope.ROLE_TYPES = ['Organizational', 'Business', 'IT'];
    $scope.LOADING = false;
    $scope.userList = [];
    $scope.roleCreationStatus = "";
    $scope.isCreateOpAllowed = false;
    
    /*
    * Role filter
    * Param: selectedRole -> Role type
    */
    $scope.changeRoleType = (selectedRole) => {
        if (selectedRole == '') {
            $scope.SHOW_ROLES = $scope.ALL_ROLES;
        } else if (selectedRole == 'Organizational') {
            $scope.SHOW_ROLES = $scope.ORG_ROLES;
        } else if (selectedRole == 'Business') {
            $scope.SHOW_ROLES = $scope.BSN_ROLES;
        } else if (selectedRole == 'IT') {
            $scope.SHOW_ROLES = $scope.IT_ROLES;
        }
    }

    /*
    * Show roles, SCIM API call to fetch all the roles available
    */
    $scope.showRole = () => {
        $scope.ATV_INDEX = 0;
    	$scope.LOADING = true;
    	$scope.ALL_ROLES = [];
        $scope.ORG_ROLES = [];
        $scope.BSN_ROLES = [];
        $scope.IT_ROLES = [];
        $scope.SHOW_ROLES = [];
    	var ROLE_API_URL = "http://localhost:8080/identityiq/scim/v2/Roles";
        var headers = {};
        
        if ($scope.currentUser == 'spadmin') {
        	this.headers = {
                    "Authorization" : `Basic ${btoa('spadmin:admin')}`
                }
        } else {
        	this.headers = {
                    "Authorization" : `Basic ${btoa(`${$scope.currentUser}:xyzzy`)}`
                }
        }
        
        $http.get(ROLE_API_URL, {headers : headers}).then(function(response) {
            if (response.status == 200) {
                $scope.ALL_ROLES = response.data.Resources;
                $scope.SHOW_ROLES = $scope.ALL_ROLES;
                for (let i = 0; i < $scope.ALL_ROLES.length; i++) {
                    if ($scope.ALL_ROLES[i].type.name == 'organizational') {
                        $scope.ORG_ROLES.push($scope.ALL_ROLES[i]);
                    } else if ($scope.ALL_ROLES[i].type.name == 'business') {
                        $scope.BSN_ROLES.push($scope.ALL_ROLES[i]);
                    } else if ($scope.ALL_ROLES[i].type.name == 'it') {
                        $scope.IT_ROLES.push($scope.ALL_ROLES[i]);
                    }
                }
                $scope.LOADING = false;
            }
        }, function(error) {
            console.log(error);
        });
    }
    
    /*
    * Switch to create role page
    */
    $scope.createRole = () => {
    	$scope.ATV_INDEX = 1;
    	$scope.roleCreationStatus = "";
    }
    
    /*
    * Create role function
    * Param: 
    *       roleName -> Name of the role
    *       roleDesc -> Description of the role
    *       selectedOwner -> Owner for the role
    *       status -> Whether the role will be enabled or not
    */
    $scope.createRoleMethod = (roleName, roleDesc, roleType, selectedOwner, status) => {
    	
    	var data = {
    		"name": roleName,
    		"desc": roleDesc,
    		"type": roleType,
    		"owner": selectedOwner,
    		"status": status
    	};
    
    	var CREATE_ROLE_URL = "http://localhost:8080/identityiq/plugin/rest/role/createRole";
    	var headers = {
                "X-XSRF-TOKEN" : PluginHelper.getCsrfToken()
        }
    	
    	$http.post(CREATE_ROLE_URL, data, {headers: headers}).then(function(response) {
    		console.log(response.data);
    		$scope.roleCreationStatus = response.data;
    	});
    }
    
    /*
    * Fetching all the identities display name and user name for the owner drop-down
    */
    (function(){
    	$scope.userList = [];
    	var USER_API_URL = "http://localhost:8080/identityiq/scim/v2/Users";
        var headers = {};
        
        console.log(PluginHelper.getPluginRestUrl('demorole1'));
        
        if ($scope.currentUser == 'spadmin') {
        	this.headers = {
                    "Authorization" : `Basic ${btoa('spadmin:admin')}`
                }
        	$scope.isCreateOpAllowed = true;
        } else {
        	
        	this.headers = {
                    "Authorization" : `Basic ${btoa(`${$scope.currentUser}:xyzzy`)}`
                }
        }
        
        $http.get(USER_API_URL, {headers : headers}).then(function(response) {
            if (response.status == 200) {
               for (let i = 0; i < response.data.Resources.length; i++) {
            	   var userObj = {
            			   'displayName': response.data.Resources[i].displayName,
            			   'userName': response.data.Resources[i].userName
            	   };
            	   $scope.userList.push(userObj);
               }
            }
        }, function(error) {
            console.log(error);
        });
              
    }());
    
    /*
    * Modal popup for viewing role details
    * Param: role -> Role object
    */
    $scope.viewRoleDetail = function(role) {
        $uibModal.open({
            animation: false,
            controller: 'RoleDetailsCtrl as ctrl',
            keyboard: false,
            templateUrl: PluginHelper.getPluginFileUrl('demorole1', 'ui/html/role-details-modal.html'),
            resolve: {
                roleData: function() {
                    return role;
                },
                currentUser: function() {
                	return $scope.currentUser;
                },
                userList: function() {
                	return $scope.userList;
                }
            }
        });
    };
    
}

);

/*
* Controller for modal popup
*/
ksModule.controller('RoleDetailsCtrl', function($scope, $uibModalInstance, $http, roleData, currentUser, userList) {

	var ctrl = this;
	
    $scope.role = roleData;
    $scope.currentUser = currentUser;
    $scope.userList = userList;
    $scope.roleEditStatus = "";
    
    $scope.obj = {
    	oldRoleName: roleData.name,
    	newRoleName: roleData.name,
    	newOwnerName: roleData.owner.displayName,
    	newStatus: roleData.active
    };
    
    /*
    * Close modal
    */
    $scope.close = function() {
        $uibModalInstance.close();
    };
    
    /*
    * Edit role
    */
    $scope.save = function() {    		
        	var EDIT_ROLE_URL = "http://localhost:8080/identityiq/plugin/rest/role/editRole";
        	var headers = {
                    "X-XSRF-TOKEN" : PluginHelper.getCsrfToken()
            }
        	
        	$http.put(EDIT_ROLE_URL, $scope.obj, {headers: headers}).then(function(response) {
        		console.log(response.data);
        		$scope.roleEditStatus = response.data;
        	});
    }
});